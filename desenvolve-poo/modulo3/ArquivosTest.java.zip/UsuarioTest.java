package com.mycompany.app;
import org.junit.Test;
import static org.junit.Assert.*;

public class UsuarioTest {

    @Test
    public void testGetIdade() {
        Livro[] livros = new Livro[0]; // Supondo que a classe Livro exista
        Emprestimo[] emprestimos = new Emprestimo[0]; // Supondo que a classe Emprestimo exista
        Usuario usuario = new Usuario("João", livros, 25, emprestimos);
        assertEquals(25, usuario.getIdade());
    }

    @Test
    public void testSetIdade() {
        Livro[] livros = new Livro[0]; // Supondo que a classe Livro exista
        Emprestimo[] emprestimos = new Emprestimo[0]; // Supondo que a classe Emprestimo exista
        Usuario usuario = new Usuario("João", livros, 25, emprestimos);
        usuario.setIdade(30);
        assertEquals(30, usuario.getIdade());
    }

    @Test
    public void testGetHistoricoEmprestimos() {
        Livro[] livros = new Livro[0]; // Supondo que a classe Livro exista
        Emprestimo[] emprestimos = new Emprestimo[2]; // Supondo que a classe Emprestimo exista
        Usuario usuario = new Usuario("João", livros, 25, emprestimos);
        assertArrayEquals(emprestimos, usuario.getHistoricoEmprestimos());
    }

    @Test
    public void testSetHistoricoEmprestimos() {
        Livro[] livros = new Livro[0]; // Supondo que a classe Livro exista
        Emprestimo[] emprestimos1 = new Emprestimo[2]; // Supondo que a classe Emprestimo exista
        Emprestimo[] emprestimos2 = new Emprestimo[3]; // Supondo que a classe Emprestimo exista
        Usuario usuario = new Usuario("João", livros, 25, emprestimos1);
        usuario.setHistoricoEmprestimos(emprestimos2);
        assertArrayEquals(emprestimos2, usuario.getHistoricoEmprestimos());
    }

    @Test
    public void testGetNome() {
        Livro[] livros = new Livro[0]; // Supondo que a classe Livro exista
        Emprestimo[] emprestimos = new Emprestimo[0]; // Supondo que a classe Emprestimo exista
        Usuario usuario = new Usuario("João", livros, 25, emprestimos);
        assertEquals("João", usuario.getNome());
    }

    @Test
    public void testSetNome() {
        Livro[] livros = new Livro[0]; // Supondo que a classe Livro exista
        Emprestimo[] emprestimos = new Emprestimo[0]; // Supondo que a classe Emprestimo exista
        Usuario usuario = new Usuario("João", livros, 25, emprestimos);
        usuario.setNome("Maria");
        assertEquals("Maria", usuario.getNome());
    }

    @Test
    public void testGetLivros() {
        Livro[] livros = new Livro[2]; // Supondo que a classe Livro exista
        Emprestimo[] emprestimos = new Emprestimo[0]; // Supondo que a classe Emprestimo exista
        Usuario usuario = new Usuario("João", livros, 25, emprestimos);
        assertArrayEquals(livros, usuario.getLivros());
    }

    @Test
    public void testSetLivros() {
        Livro[] livros1 = new Livro[2]; // Supondo que a classe Livro exista
        Livro[] livros2 = new Livro[3]; // Supondo que a classe Livro exista
        Emprestimo[] emprestimos = new Emprestimo[0]; // Supondo que a classe Emprestimo exista
        Usuario usuario = new Usuario("João", livros1, 25, emprestimos);
        usuario.setLivros(livros2);
        assertArrayEquals(livros2, usuario.getLivros());
    }
}