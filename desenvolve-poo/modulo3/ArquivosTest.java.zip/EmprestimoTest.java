package com.mycompany.app;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.Date;

public class EmprestimoTest {

    @Test
    public void testGetDataRetirada() {
        Date dataRetirada = new Date();
        Date dataDevolucao = new Date();
        Livro livro = new Livro("Livro1", new Autor("Autor1", new Livro[0], "Brasileiro"), "Ficção");
        Usuario usuario = new Usuario("Usuario1", new Livro[0], 25, new Emprestimo[0]);
        Emprestimo emprestimo = new Emprestimo(dataRetirada, dataDevolucao, livro, usuario);
        assertEquals(dataRetirada, emprestimo.getDataRetirada());
    }

    @Test
    public void testGetDataDevolucao() {
        Date dataRetirada = new Date();
        Date dataDevolucao = new Date();
        Livro livro = new Livro("Livro1", new Autor("Autor1", new Livro[0], "Brasileiro"), "Ficção");
        Usuario usuario = new Usuario("Usuario1", new Livro[0], 25, new Emprestimo[0]);
        Emprestimo emprestimo = new Emprestimo(dataRetirada, dataDevolucao, livro, usuario);
        assertEquals(dataDevolucao, emprestimo.getDataDevolucao());
    }

    @Test
    public void testGetLivro() {
        Date dataRetirada = new Date();
        Date dataDevolucao = new Date();
        Livro livro = new Livro("Livro1", new Autor("Autor1", new Livro[0], "Brasileiro"), "Ficção");
        Usuario usuario = new Usuario("Usuario1", new Livro[0], 25, new Emprestimo[0]);
        Emprestimo emprestimo = new Emprestimo(dataRetirada, dataDevolucao, livro, usuario);
        assertEquals(livro, emprestimo.getLivro());
    }

    @Test
    public void testGetUsuario() {
        Date dataRetirada = new Date();
        Date dataDevolucao = new Date();
        Livro livro = new Livro("Livro1", new Autor("Autor1", new Livro[0], "Brasileiro"), "Ficção");
        Usuario usuario = new Usuario("Usuario1", new Livro[0], 25, new Emprestimo[0]);
        Emprestimo emprestimo = new Emprestimo(dataRetirada, dataDevolucao, livro, usuario);
        assertEquals(usuario, emprestimo.getUsuario());
    }
}