package com.mycompany.app;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

public class LivroTest {

    private Autor autor;
    private Livro livro;

    @Before
    public void setUp() {
        autor = new Autor("Autor1", new Livro[0], "Brasileiro");
        livro = new Livro("Livro1", autor, "Ficção");
    }

    @Test
    public void testGetTitulo() {
        assertEquals("Livro1", livro.getTitulo());
    }

    @Test
    public void testGetAutor() {
        assertEquals(autor, livro.getAutor());
    }

    @Test
    public void testGetGenero() {
        assertEquals("Ficção", livro.getGenero());
    }

    @Test
    public void testIsDisponivel() {
        assertTrue(livro.isDisponivel());
    }

    @Test
    public void testSetDisponivel() {
        livro.setDisponivel(false);
        assertFalse(livro.isDisponivel());
    }

    @Test
    public void testValidarEmprestimoDisponivel() {
        livro.setDisponivel(true);
        // Capturar a saída do console
        java.io.ByteArrayOutputStream outContent = new java.io.ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(outContent));

        livro.validarEmprestimo();

        assertEquals("Livro disponivel para emprestimo.\n", outContent.toString());
    }

    @Test
    public void testValidarEmprestimoIndisponivel() {
        livro.setDisponivel(false);
        // Capturar a saída do console
        java.io.ByteArrayOutputStream outContent = new java.io.ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(outContent));

        livro.validarEmprestimo();

        assertEquals("O livro nao esta disponivel\n", outContent.toString());
    }
}